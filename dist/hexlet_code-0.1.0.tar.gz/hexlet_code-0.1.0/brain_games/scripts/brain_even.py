from brain_games import brain_main
from brain_games.games import even

def main():
    brain_main.main(even)


if __name__ == "__main__":
    main()
    
from brain_games.games import calc
from brain_games import brain_main


def main():
    brain_main.main(calc)


if __name__ == "__main__":
    main()

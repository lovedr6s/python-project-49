def welcome_user():
    name = input("May i have your name?: ")
    print(f"Hello, {name}!")

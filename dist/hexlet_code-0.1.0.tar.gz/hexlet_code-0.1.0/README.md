### Hexlet tests and linter status:
[![Actions Status](https://github.com/lovedr6s/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/lovedr6s/python-project-49/actions)


[![Maintainability](https://api.codeclimate.com/v1/badges/d5fa61b58bf3275b66cb/maintainability)](https://codeclimate.com/github/lovedr6s/python-project-49/maintainability)

Project was made for Hexlet by lovedr6s

It has 5 math games.

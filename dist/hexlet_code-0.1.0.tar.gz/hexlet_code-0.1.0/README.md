### Hexlet tests and linter status:
[![Actions Status](https://github.com/lovedr6s/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/lovedr6s/python-project-49/actions)


[![Maintainability](https://api.codeclimate.com/v1/badges/d5fa61b58bf3275b66cb/maintainability)](https://codeclimate.com/github/lovedr6s/python-project-49/maintainability)